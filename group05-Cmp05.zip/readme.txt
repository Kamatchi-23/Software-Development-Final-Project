Assessment 2 – Part 2: Software Development
32555 Fundamentals of Software Development

Session: Autumn 2024

Group 5, Cmp 5:
• Zagarsuren Sukhbaatar 
• Kamatchi Gnanavel 
• Megha George 
• Yashpreet Kaur 

Contribution:
• Zagarsuren Sukhbaatar :
-- For CLI, 
	1. Subjects.py file 
		a. Assign new subjects
		b. calculate average mark
		c. calculate grades  
	2. Students.py file - 
		a. Enrol Subjects
		b. View Subjects

• Kamatchi Gnanavel :
-- For CLI,
	1. Students.py file -
		a. Student Menu and Course menu with corresponding help menu options
		b. Registration
		c. Login
		d. Change Password
		e. Remove a subject
	2. Database - DataFile.py - create file, read, write, clear database
-- GUI task - login, enroll, view subjects and handle exceptions

• Megha George :
-- For CLI, 
	1. Admins.py file
		a. Group students by grades
		b. Partition students by pass/fail
		c. Admin menu and help menu options
	2. UniApp.py file
		a. University menu and help menu options

• Yashpreet Kaur:
-- For CLI, 
	1. Admins.py file
		a. View all students
		b. Remove a student record
		c. Remove all student records on the database




